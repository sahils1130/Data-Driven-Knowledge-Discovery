connection = new Mongo('localhost:27017');
db = connection.getDB('Cruise1');
collection = db.getCollection('Cruises');

1.	Insert the documents into a database called Cruise1, collection Cruises.







2.	Write a query to list all the json documents (pretty()) in the Cruises collection.





